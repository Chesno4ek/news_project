function toggleMenu() {
    let menuList = document.getElementById("menuList");
    if (menuList.style.display === "none") {
        menuList.style.display = "block";
    } else {
        menuList.style.display = "none";
    }
}