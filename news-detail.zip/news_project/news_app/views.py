from django.shortcuts import render,  get_object_or_404
from .models import post

def home_page(request):
    posts = post.objects.all()[:4]
    return render(request, "./primary/index.html", {'posts': posts})

def news_page(request):
    return render(request, "./primary/news.html")

def news_detail_page(request, pk):
    post = get_object_or_404(post, pk=pk)
    return render(request, "./primary/news-detail.html", {'post': post})
